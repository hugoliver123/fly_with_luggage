$(function (){
    $("#sub_btn").click(function (){
        var heavyText = $("#heavy").val();
        var heavyText2 = parseInt(heavyText);
        if(heavyText2<0 || heavyText2>69 || heavyText == null || heavyText == ""){
            alert("please input 0 to 69");
            return false;
        }

    })
})