$(function (){
    var curWwwPath=window.document.location.href;
    var pathName=window.document.location.pathname;
    var pos=curWwwPath.indexOf(pathName);
    var localhostPaht=curWwwPath.substring(0,pos);
    var projectName=pathName.substring(0,pathName.substr(1).indexOf('/')+1);
    var action_path = localhostPaht + projectName + "/mail";
    var linkTarget = action_path;
    document.getElementById("mailForm").action = linkTarget;
    alert("fsdfsa")
    $("#loginBtn").click(function (){
        var emailText = ($("#email").val());
        alert(emailText);
        var emailPatt = /^([A-Za-z0-9_\-\.])+\@([A-Za-z0-9_\-\.])+\.([A-Za-z]{2,4})$/;
        if(!emailPatt.test(emailText)){
            alert("invalid e-mail input");
            return false;
        }
    })
})