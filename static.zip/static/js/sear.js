window.onload = function (){
            // 获取当前日期
            var date = new Date();
            // 获取当前月份
            var nowMonth = date.getMonth() + 1;
            // 获取当前是几号
            var strDate = date.getDate();
            // 添加分隔符“-”
            var seperator = "-";
            // 对月份进行处理，1-9月在前面添加一个“0”
            if (nowMonth >= 1 && nowMonth <= 9) {
                nowMonth = "0" + nowMonth;
            }
            // 对月份进行处理，1-9号在前面添加一个“0”
            if (strDate >= 0 && strDate <= 9) {
                strDate = "0" + strDate;
            }
            // 最后拼接字符串，得到一个格式为(yyyy-MM-dd)的日期
            var nowDate = date.getFullYear() + seperator + nowMonth + seperator + strDate;
            document.getElementById("date").min = nowDate;
            document.getElementById("date").value = nowDate;
        }
        function toLink(){
            document.getElementById("departure").value = document.getElementById("departure").value.substr(0,3);
            document.getElementById("destination").value = document.getElementById("destination").value.substr(0,3);

            var heavy = document.getElementById("heavy");
            var departure = document.getElementById("departure");
            var destination = document.getElementById("destination");

            var date = document.getElementById("date");
            date = date.value.split('-');
            var subDate = date[0].substr(2,3) + date[1] + date[2];

            if(departure.value == destination.value){
                alert("please enter different airport");
                return false;
            }

            var curWwwPath=window.document.location.href;
            //获取主机地址之后的目录如：/chenThree/jspPage/pages/projectImplementation.html
            var pathName=window.document.location.pathname;
            var pos=curWwwPath.indexOf(pathName);
            var localhostPaht=curWwwPath.substring(0,pos);
            //获取带"/"的项目名，如：/chenThree
            var projectName=pathName.substring(0,pathName.substr(1).indexOf('/')+1);
            var action_path = localhostPaht + projectName + "/createSearch";

            var linkTarget = action_path;

            var obj =document.getElementById("sub_btn");
            var inputPar = obj.parentNode;
            inputPar.removeChild(obj);

            document.getElementById("myForm").action = linkTarget;

        }